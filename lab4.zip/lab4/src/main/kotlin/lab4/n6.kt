package lab4

fun main() {
    // Вывод заголовка таблицы
    println("Таблица умножения:")

    // Вывод первой строки с номерами столбцов
    print("   ")
    for (column in 1..10) {
        print("%4d".format(column))
    }
    println() // Перейти на следующую строку

    // Вывод таблицы умножения
    for (row in 1..10) {
        print("%2d |".format(row)) // Вывод номера строки

        for (column in 1..10) {
            val result = row * column
            print("%4d".format(result)) // Вывод результата умножения
        }

        println() // Перейти на следующую строку
    }
}