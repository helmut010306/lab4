package lab4

    import kotlin.random.Random

    fun main() {
        val random = Random(System.currentTimeMillis())
        val ex1Grade = random.nextInt(1, 11)
        val ex1Preparation = random.nextBoolean()
        val ex2Grade = random.nextInt(1, 11)
        val ex2Preparation = random.nextBoolean()
        val ex3Grade = random.nextInt(1, 11)
        val ex3Preparation = random.nextBoolean()
    println("Экзамен 1: Оценка - $ex1Grade, Подготовка - ${if (ex1Preparation) "Хорошо" else "Плохо"}")
    println("Экзамен 2: Оценка - $ex2Grade, Подготовка - ${if (ex2Preparation) "Хорошо" else "Плохо"}")
    println("Экзамен 3: Оценка - $ex3Grade, Подготовка - ${if (ex3Preparation) "Хорошо" else "Плохо"}")
}