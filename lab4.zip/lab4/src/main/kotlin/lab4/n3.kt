package lab4

fun main() {
    val hum = 10000
    val hex = 14
    val kak = 8
    val ham = if (hex < 7) 7 else hex
    val faf = if (kak < 6) 6 else kak


    val mmm =
        hum + (hum * ham * 0.001 - hum * faf * 0.001 - 1)

    println("Численность населения через 10 лет: " + "$mmm")
}