package lab4

import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)

    // Ввод суммы вклада и количества месяцев
    print("Введите сумму вклада (в рублях): ")
    val initialDeposit = scanner.nextFloat()

    print("Введите количество месяцев: ")
    val numberOfMonths = scanner.nextInt()

    // Годовая процентная ставка
    val annualInterestRate: Float = 7.0f // Годовая ставка в процентах

    var deposit: Float = initialDeposit
    var month = 1

    while (month <= numberOfMonths) {
        val monthlyInterest = deposit * (annualInterestRate / 12 / 100)
        deposit += monthlyInterest
        month++
    }

    println("Сумма вклада через $numberOfMonths месяцев: $deposit рублей")
}